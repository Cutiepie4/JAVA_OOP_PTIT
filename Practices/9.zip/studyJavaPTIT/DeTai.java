package studyJavaPTIT;

public class DeTai {
	private String tenGV, tenDeTai, maDT;
	private static int count = 1;

	public DeTai(String tenGV, String tenDeTai) {
		super();
		this.tenGV = tenGV;
		this.tenDeTai = tenDeTai;
		if (DeTai.count < 10) {
			this.maDT = "DT00" + DeTai.count;
		} else if (DeTai.count < 100) {
			this.maDT = "DT0" + DeTai.count;
		} else
			this.maDT = "DT" + DeTai.count;
		DeTai.count++;
	}

	public String getTenDeTai() {
		return tenDeTai;
	}

	public String getTenGV() {
		return tenGV;
	}

	public String getMaDT() {
		return maDT;
	}

}
