package studyJavaPTIT;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {

		Scanner sc = new Scanner(new File("SINHVIEN.in"));

		int n = Integer.valueOf(sc.nextLine());

		ArrayList<SinhVien> listSV = new ArrayList<>();

		while (n-- > 0) {
			listSV.add(new SinhVien(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine()));
		}

		sc = new Scanner(new File("DETAI.in"));

		n = Integer.valueOf(sc.nextLine());

		ArrayList<DeTai> listDT = new ArrayList<>();

		while (n-- > 0) {
			listDT.add(new DeTai(sc.nextLine(), sc.nextLine()));
		}

		sc = new Scanner(new File("NHIEMVU.in"));

		n = Integer.valueOf(sc.nextLine());

		ArrayList<NhiemVu> listNV = new ArrayList<>();

		while (n-- > 0) {
			String maSV = sc.next(), maDT = sc.next();
			outer: for (SinhVien i : listSV) {
				if (i.getMaSV().equals(maSV)) {
					for (DeTai j : listDT) {
						if (j.getMaDT().equals(maDT)) {
							listNV.add(new NhiemVu(i, j));
							break outer;
						}
					}
				}
			}
		}

		Collections.sort(listNV);

		for (NhiemVu i : listNV) {
			System.out.println(i);
		}
	}
}