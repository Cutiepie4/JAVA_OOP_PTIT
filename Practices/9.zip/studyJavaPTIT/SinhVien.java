package studyJavaPTIT;

public class SinhVien {

	private String maSV, tenSV, soDT, email;
	
	public SinhVien(String maSV, String hoTen, String soDT, String email) {
		super();
		this.maSV = maSV;
		this.tenSV = hoTen;
		this.soDT = soDT;
		this.email = email;
	}

	public String getMaSV() {
		return maSV;
	}

	public String getTenSV() {
		return tenSV;
	}

	public String getSoDT() {
		return soDT;
	}

	public String getEmail() {
		return email;
	}


				
}
