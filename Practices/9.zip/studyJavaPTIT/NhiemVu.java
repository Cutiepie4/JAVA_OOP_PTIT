package studyJavaPTIT;

public class NhiemVu implements Comparable {

	private SinhVien sv;
	private DeTai dt;

	public NhiemVu(SinhVien sv, DeTai dt) {
		super();
		this.sv = sv;
		this.dt = dt;
	}

	@Override
	public String toString() {
		return this.sv.getMaSV() + " " + this.sv.getTenSV() + " " + this.sv.getSoDT() + " " + this.sv.getEmail() + " "
				+ this.dt.getTenGV() + " " + this.dt.getTenDeTai();
	}

	@Override
	public int compareTo(Object o) {
		NhiemVu a = (NhiemVu) o;
		return this.getDt().getTenDeTai().compareTo(a.getDt().getTenDeTai());
	}

	public SinhVien getSv() {
		return sv;
	}

	public DeTai getDt() {
		return dt;
	}

}
