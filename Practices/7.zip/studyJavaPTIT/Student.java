package studyJavaPTIT;

public class Student implements Comparable {
	private String nameStu, idStu;
	private Team team;

	public Student(String nameStu, Team team) {
		super();
		this.nameStu = nameStu;
		this.team = team;
		if (Team.getCount() < 10) {
			this.idStu = "C00" + Team.getCount();
		} else if (Team.getCount() < 100) {
			this.idStu = "C0" + Team.getCount();
		} else
			this.idStu = "C" + Team.getCount();
		Team.incrCount();
	}

	@Override
	public String toString() {
		return idStu + " " + nameStu + " " + this.team.getNameTeam() + " " + this.team.getOrganization();
	}

	@Override
	public int compareTo(Object o) {
		Student a = (Student) o;

		return this.nameStu.compareTo(a.getNameStu());
	}

	public String getNameStu() {
		return nameStu;
	}

}
