package studyJavaPTIT;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int n = Integer.valueOf(sc.nextLine());

		ArrayList<Team> listTeam = new ArrayList<>();
		ArrayList<Student> listStudent = new ArrayList<>();

		for (int i = 0; i < n; i++) {
			listTeam.add(new Team(i + 1, sc.nextLine(), sc.nextLine()));
		}
 
		n = Integer.valueOf(sc.nextLine());

		for (int i = 0; i < n; i++) {
			String name = sc.nextLine(), team = sc.nextLine();
			
			for (Team j : listTeam) {
				if (j.getIdTeam().equals(team)) {
					listStudent.add(new Student(name, j));
					break;
				}
			}
		}

		Collections.sort(listStudent);

		for (Student i : listStudent) {
			System.out.println(i);
		}
		
	}
}