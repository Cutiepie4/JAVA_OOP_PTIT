package studyJavaPTIT;

import java.util.ArrayList;

public class Team {
	private String idTeam, nameTeam, organization;
	private ArrayList<Student> mems;
	private static int count = 1;

	public Team(int id, String nameTeam, String organization) {
		super();
		if (id < 10)
			this.idTeam = "Team0" + id;
		else
			this.idTeam = "Team" + id;
		this.nameTeam = nameTeam;
		this.organization = organization;
		this.mems = new ArrayList<>();
	}

	public void addMem(String name) {
		this.mems.add(new Student(name, this));
	}

	public String getIdTeam() {
		return idTeam;
	}

	public String getNameTeam() {
		return nameTeam;
	}

	public String getOrganization() {
		return organization;
	}

	public ArrayList<Student> getMems() {
		return mems;
	}

	public static int getCount() {
		return count;
	}

	public static void incrCount() {
		Team.count++;
	}

}
