package studyJavaPTIT;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {

		Scanner sc = new Scanner(new File("LUYENTAP.in"));

		int t = sc.nextInt();
		ArrayList<SinhVien> data = new ArrayList<SinhVien>();

		while (t-- > 0) {
			sc.nextLine();
			data.add(new SinhVien(sc.nextLine(), sc.nextInt(), sc.nextInt()));
		}

		Collections.sort(data);

		for (SinhVien i : data) {
			System.out.println(i);
		}
	}
}