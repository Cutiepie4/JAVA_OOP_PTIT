package studyJavaPTIT;

public class SinhVien implements Comparable {
	private String hoTen;
	private int sub, ac;

	public SinhVien(String hoTen, int ac, int sub) {
		super();
		this.hoTen = hoTen;
		this.sub = sub;
		this.ac = ac;
	}

	@Override
	public int compareTo(Object o) {
		SinhVien a = (SinhVien) o;

		if (this.ac > a.getAc()) {
			return -1;
		} else if (this.ac == a.getAc() && this.sub < a.getSub()) {
			return -1;
		} else if (this.ac == a.getAc() && this.ac == a.getSub()) {
			return this.hoTen.compareTo(a.getHoTen());
		}
		return 1;
	}

	public String getHoTen() {
		return hoTen;
	}

	public int getSub() {
		return sub;
	}

	public int getAc() {
		return ac;
	}

	@Override
	public String toString() {
		return this.hoTen + " " + this.ac + " " + this.sub;
	}

}
