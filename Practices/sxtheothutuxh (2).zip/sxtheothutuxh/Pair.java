package sxtheothutuxh;

public class Pair implements Comparable<Pair> {
	private int data, count, pos;

	public Pair(int data, int count, int pos) {
		super();
		this.data = data;
		this.count = count;
		this.pos = pos;
	}

	@Override
	public int compareTo(Pair o) {
		if (this.count > o.count)
			return -1;
		if (this.count == o.count && this.pos < o.pos)
			return -1;
		return 1;
	}

	@Override
	public String toString() {
		return String.valueOf(data);
	}

}
