package sxtheothutuxh;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int t = sc.nextInt();

		while (t-- > 0) {
			int n = sc.nextInt();
			HashMap<Integer, Integer> data = new HashMap<>();
			HashMap<Integer, Integer> pos = new HashMap<>();

			ArrayList<Integer> arr = new ArrayList<>();

			for (int i = 0; i < n; i++) {
				int x = sc.nextInt();
				arr.add(x);
				if (!data.containsKey(x)) {
					data.put(x, 0);
				}
				data.put(x, data.get(x) + 1);
				if (!pos.containsKey(x)) {
					pos.put(x, i);
				}

			}

			ArrayList<Pair> ans = new ArrayList<>();

			for (int i = 0; i < arr.size(); i++) {
				ans.add(new Pair(arr.get(i), data.get(arr.get(i)), pos.get(arr.get(i))));
			}

			Collections.sort(ans);

			for (Pair i : ans) {
				System.out.print(i + " ");
			}
			System.out.println();
		}
	}
}
