package sobuocdichuyenitnhat;

public class Point {
	private int x, y, cnt;

	public Point(int x, int y, int cnt) {
		super();
		this.x = x;
		this.y = y;
		this.cnt = cnt;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getCnt() {
		return cnt;
	}
	
	
}
