package sobuocdichuyenitnhat;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main {
	public static int X[] = { 0, 1, 1 };
	public static int Y[] = { 1, 0, 1 };

	public static int bfs(int M[][], int r, int c) {

		int ans = -1;

		boolean[][] mark = new boolean[1000][1000];

		mark[0][0] = true;

		Queue<Point> q = new LinkedList<>();

		q.add(new Point(0, 0, 0));

		while (!q.isEmpty()) {
			Point p = q.poll();

			if (p.getX() == r - 1 && p.getY() == c - 1) {
				return p.getCnt();
			}

			int step = Math.abs(M[p.getX()][p.getY()] - M[p.getX()][p.getY() + 1]);
			if (p.getY() + step >= 0 && p.getY() + step < c && mark[p.getX()][p.getY() + step] == false) {
				q.add(new Point(p.getX(), p.getY() + step, p.getCnt() + 1));
				mark[p.getX()][p.getY() + step] = true;
			}

			step = Math.abs(M[p.getX()][p.getY()] - M[p.getX() + 1][p.getY()]);
			if (p.getX() + step >= 0 && p.getX() + step < r && mark[p.getX() + step][p.getY()] == false) {
				q.add(new Point(p.getX() + step, p.getY(), p.getCnt() + 1));
				mark[p.getX() + step][p.getY()] = true;
			}

			step = Math.abs(M[p.getX()][p.getY()] - M[p.getX() + 1][p.getY() + 1]);
			if (p.getX() + step >= 0 && p.getX() + step < r && p.getY() + step >= 0 && p.getY() + step < c
					&& mark[p.getX() + step][p.getY() + step] == false) {
				q.add(new Point(p.getX() + step, p.getY() + step, p.getCnt() + 1));
				mark[p.getX() + step][p.getY() + step] = true;
			}

		}

		return -1;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int t = sc.nextInt();

		while (t-- > 0) {
			int r = sc.nextInt(), c = sc.nextInt();

			int[][] M = new int[1000][1000];

			for (int i = 0; i < r; i++) {
				for (int j = 0; j < c; j++) {
					M[i][j] = sc.nextInt();
				}
			}

			System.out.println(bfs(M, r, c));
		}
	}
}
