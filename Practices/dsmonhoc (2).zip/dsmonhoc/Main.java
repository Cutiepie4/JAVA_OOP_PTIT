package dsmonhoc;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(new File("MONHOC.in"));

		ArrayList<MonHoc> data = new ArrayList<MonHoc>();

		HashSet<String> check = new HashSet<>();

		while (sc.hasNextLine()) {
			String a = sc.nextLine(), b = sc.nextLine(), c = sc.nextLine();
			if (!check.contains(a)) {
				data.add(new MonHoc(a, b, c));
				check.add(a);
			}
		}

		Collections.sort(data);

		for (MonHoc i : data) {
			System.out.println(i);
		}
	}
}
