package dsmonhoc;

public class MonHoc implements Comparable<MonHoc>{
	private String ma, ten, ht;

	public MonHoc(String ma, String ten, String ht) {
		super();
		this.ma = ma;
		this.ten = ten;
		this.ht = ht;
	}

	@Override
	public String toString() {
		return ma + " " + ten + " " + ht;
	}

	@Override
	public int compareTo(MonHoc o) {
		return this.ma.compareTo(o.ma);
	}

}
