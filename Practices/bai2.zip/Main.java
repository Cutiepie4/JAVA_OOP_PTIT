package practices;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {

	public static String convert(ArrayList<String> data) {
		String ans = "";
		for (String i : data) {
			ans += i;
		}
		return ans;
	}

	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(new File("DANHSACH.in"));

		HashMap<String, Integer> count = new HashMap<>();
		HashSet<String> check = new HashSet<>();

		while (sc.hasNextLine()) {
			String s = sc.nextLine();

			String ans = "";

			StringTokenizer st = new StringTokenizer(s);

			ArrayList<String> data = new ArrayList<>();

			while (st.hasMoreTokens()) {
				data.add(st.nextToken().toLowerCase());
			}

			String temp = convert(data);

			if (check.contains(temp)) {
				continue;
			} else
				check.add(temp);

			ans += data.get(data.size() - 1);

			for (int i = 0; i < data.size() - 1; i++) {
				ans += String.valueOf(data.get(i).charAt(0));
			}

			if (count.containsKey(ans)) {
				count.put(ans, count.get(ans) + 1);
				System.out.println(ans + count.get(ans) + "@ptit.edu.vn");
			} else {
				count.put(ans, 1);
				System.out.println(ans + "@ptit.edu.vn");
			}
		}

	}
}
