package practices;

public class Pair<K, V> {
	private K fi;
	private V se;

	public Pair(K fi, V se) {
		super();
		this.fi = fi;
		this.se = se;
	}

	@Override
	public String toString() {
		return "(" + fi + "," + se + ")";
	}

}
