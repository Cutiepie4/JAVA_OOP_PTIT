package practices;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main {

	public static ArrayList<String> data = new ArrayList<>();

	public static void init() {
		Queue<Pair<String, Integer>> queue = new LinkedList<>();

		queue.add(new Pair<>("", 0));

		while (true) {
			Pair<String, Integer> p = queue.poll();

			String s = p.getFi();
			int cnt = p.getSe();

			if (s.charAt(0) != '0' && cnt > s.length() / 2) {
				data.add(s);
			}

			if (data.size() > 1000)
				return;

			queue.offer(new Pair<>(s + "0", cnt));
			queue.offer(new Pair<>(s + "1", cnt));
			queue.offer(new Pair<>(s + "2", cnt + 1));
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		init();
		int t = sc.nextInt();

		while (t-- > 0) {
			int n = sc.nextInt();
			for (int i = 0; i < n; i++) {
				System.out.println(data.get(i));
			}
		}

	}
}
