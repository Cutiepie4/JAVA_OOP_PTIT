package practices;

public class Pair<K, V> {
	private K fi;
	private V se;
	public Pair(K fi, V se) {
		super();
		this.fi = fi;
		this.se = se;
	}
	public K getFi() {
		return fi;
	}
	public V getSe() {
		return se;
	}
	
}
