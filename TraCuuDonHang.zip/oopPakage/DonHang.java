package oopPakage;


public class DonHang {
	private String name, id, ord;
	private long count, unitPrice;

	public DonHang(String name, String id, long unitPrice, long count) {
		super();
		this.name = name;
		this.id = id;
		this.ord = id.substring(1, 4);
		this.unitPrice = unitPrice;
		this.count = count;
	}

	public String getOrder() {
		return id.substring(1);
	}

	public long getPrice() {
		return count * unitPrice;
	}

	public long getDiscountPrice() {
		if (id.substring(4, 5).equals("1")) {
			return getPrice() * 50 / 100;
		}
		return getPrice() * 30 / 100;
	}

	@Override
	public String toString() {
		return name + " " + id + " " + ord + " " + getDiscountPrice() + " " + (getPrice() - getDiscountPrice());
	}

}