package oopPakage;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<DonHang> data = new ArrayList<DonHang>();
		int n = Integer.valueOf(sc.nextLine());

		while (n-- > 0) {
			System.out.println(new DonHang(sc.nextLine(), sc.nextLine(), Integer.valueOf(sc.nextLine()),
					Integer.valueOf(sc.nextLine())));
		}
	}
}
