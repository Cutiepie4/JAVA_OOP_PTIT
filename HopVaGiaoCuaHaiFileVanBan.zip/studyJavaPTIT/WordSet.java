package studyJavaPTIT;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.TreeSet;

public class WordSet {

	private TreeSet<String> data;

	public WordSet(String dir) throws FileNotFoundException {
		data = new TreeSet<>();
		Scanner sc = new Scanner(new File(dir));
		while (sc.hasNext()) {
			data.add(sc.next().toLowerCase());
		}
	}

	public WordSet(TreeSet<String> data) {
		this.data = data;
	}

	public WordSet intersection(WordSet a) {
		TreeSet<String> arr = new TreeSet<String>();

		for (String i : data) {
			if (a.getData().contains(i)) {
				arr.add(i);
			}
		}

		return new WordSet(arr);
	}

	public WordSet union(WordSet a) {
		TreeSet<String> arr = new TreeSet<>();

		for (String i : this.data) {
			arr.add(i);
		}

		for (String i : a.getData()) {
			arr.add(i);
		}

		return new WordSet(arr);
	}

	public TreeSet<String> getData() {
		return data;
	}


	@Override
	public String toString() {
		String s = "";
		for (String i : data) {
			s += i + " ";
		}
		return s.trim();
	}

}
