package qlibanhang1;

import java.util.ArrayList;

public class Customer {
	public static ArrayList<Customer> listCustomer = new ArrayList<>();
	private static int idCount = 1;
	private String id, name, sex, dob, address;

	public Customer(String name, String sex, String dob, String address) {
		super();
		this.id = "KH" + String.format("%03d", Customer.idCount++);
		this.name = name;
		this.sex = sex;
		this.dob = dob;
		this.address = address;
		listCustomer.add(this);
	}

	public String getId() {
		return id;
	}

	@Override
	public String toString() {
		return this.name + " " + this.address;
	}

}
