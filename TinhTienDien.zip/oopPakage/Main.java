package oopPakage;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(new File("KHACHHANG.in"));
		int t = sc.nextInt();

		ArrayList<KhachHang> data = new ArrayList<KhachHang>();

		for (int i = 1; i <= t; i++) {
			sc.nextLine();
			data.add(new KhachHang(i, sc.nextLine(), sc.next(), sc.nextInt(), sc.nextInt()));
		}
		Collections.sort(data);
		for (KhachHang i : data) {
			System.out.println(i);
		}
	}

}