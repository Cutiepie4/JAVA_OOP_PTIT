package oopPakage;

import java.util.StringTokenizer;

public class KhachHang implements Comparable<KhachHang> {
	private String name, id;
	private int total, standard;

	public KhachHang(int id, String name, String type, int curr, int last) {
		super();
		this.id = "KH" + String.format("%02d", id);
		this.name = format(name);
		this.total = last - curr;
		switch (type) {
		case "A":
			this.standard = 100;
			break;
		case "B":
			this.standard = 500;
			break;
		case "C":
			this.standard = 200;
			break;
		}
	}

	private String format(String name) {
		StringTokenizer st = new StringTokenizer(name);
		String ans = "";
		while (st.hasMoreTokens()) {
			String temp = st.nextToken();
			ans += temp.substring(0, 1).toUpperCase() + temp.substring(1).toLowerCase() + " ";
		}
		return ans.trim();
	}

	public int inStandard() {
		if (total < standard) {
			return total * 450;
		}
		return standard * 450;
	}

	public int overStandard() {
		if (total > standard) {
			return (total - standard) * 1000;
		}
		return 0;
	}

	public int VAT() {
		return (int) (overStandard() / 100f * 5);
	}

	public int total() {
		return inStandard() + overStandard() + VAT();
	}

	@Override
	public String toString() {
		return id + " " + name + " " + inStandard() + " " + overStandard() + " " + VAT() + " " + total();
	}

	@Override
	public int compareTo(KhachHang o) {
		if (this.total() > o.total())
			return -1;
		return 1;
	}

}
