package test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeSet;

public class Main {

    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
        ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream("DATA.in"));

        ArrayList<Pair> data = (ArrayList<Pair>) inputStream.readObject();
        
        Collections.sort(data);
        System.out.println(data.get(0));
        for(int i=1; i<data.size(); i++) {
            if((data.get(i).getFirst() != data.get(i-1).getFirst() || data.get(i).getSecond() != data.get(i-1).getSecond()) && data.get(i).getFirst() < data.get(i).getSecond()) {
                System.out.println(data.get(i));
            }
        }
            
    }
 
}
