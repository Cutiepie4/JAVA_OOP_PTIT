package studyJava;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.StringTokenizer;

public class Name implements Comparable {

	private String name;
	private HashSet<String> data;
	private ArrayList<String> listWord;

	public Name(String name) {
		super();
		this.name = name;
		this.data = new HashSet<>();
		this.listWord = new ArrayList<>();
		this.split();
		this.decode();
	}

	public void split() {
		StringTokenizer st = new StringTokenizer(name);

		while (st.hasMoreTokens()) {
			listWord.add(st.nextToken());
		}
	}

	public void decode() {
		String curr = "";
		for (String i : listWord) {
			curr += i.charAt(0);
			curr += '.';
		}
		for (int i = 0; i < curr.length(); i++) {
			if (curr.charAt(i) == '.')
				continue;
			StringBuilder sb = new StringBuilder(curr);
			sb.setCharAt(i, '*');
			sb.deleteCharAt(sb.length() - 1);
			data.add(sb.toString());
		}
	}

	@Override
	public int compareTo(Object o) {
		Name a = (Name) o;

		if (a.getLastName().equals(this.getLastName()))
			return this.getName().compareTo(a.getName());
		return this.getLastName().compareTo(a.getLastName());
	}

	public String getLastName() {
		return listWord.get(listWord.size() - 1);
	}

	public String getName() {
		return name;
	}

	public HashSet<String> getData() {
		return data;
	}

}
