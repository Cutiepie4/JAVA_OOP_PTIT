package studyJava;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(new File("DANHSACH.in"));

		int n = Integer.valueOf(sc.nextLine());

		ArrayList<Name> data = new ArrayList<>();

		while (n-- > 0) {
			String s = sc.nextLine();
			data.add(new Name(s));
		}

		Collections.sort(data);

		int Q = Integer.valueOf(sc.nextLine());
		
		while (Q-- > 0) {
			String s = sc.nextLine();
			for (Name i : data) {
				if (i.getData().contains(s)) {
					System.out.println(i.getName());
				}
			}
		}

	}
}
