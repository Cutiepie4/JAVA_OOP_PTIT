package oopPakage;

public class GiaoVien {

	private String id, name;
	private int baseSalary;

	public GiaoVien(String id, String name, int baseSalary) {
		super();
		this.id = id;
		this.name = name;
		this.baseSalary = baseSalary;
	}

	private int getBonus() {
		switch (id.substring(0, 2)) {
		case "HT":
			return 2000000;
		case "HP":
			return 900000;
		case "GV":
			return 500000;
		}
		return 0;
	}

	private int getUnit() {
		return Integer.valueOf(id.substring(2));
	}

	private long getTotalSalary() {
		return this.baseSalary * this.getUnit() + this.getBonus();
	}

	public String getType() {
		return this.id.substring(0, 2);
	}

	@Override
	public String toString() {
		return this.id + " " + this.name + " " + this.getUnit() + " " + this.getBonus() + " " + this.getTotalSalary();
	}

}