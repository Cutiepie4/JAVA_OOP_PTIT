package oopPakage;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());

		int countHP = 0, countHT = 0;
		while (n-- > 0) {
			GiaoVien x = new GiaoVien(sc.nextLine(), sc.nextLine(), Integer.valueOf(sc.nextLine()));
			if (x.getType().equals("HT")) {
				countHT++;
				if (countHT < 2) {
					System.out.println(x);
				}
			}

			else if (x.getType().equals("HP")) {
				countHP++;
				if (countHP < 3) {
					System.out.println(x);
				}
			}

			else
				System.out.println(x);
		}

	}
}
