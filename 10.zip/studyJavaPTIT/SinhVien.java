package studyJavaPTIT;

public class SinhVien implements Comparable {

	private String maSV, tenSV, soDT, email, hd;
	private DeTai dt;

	public SinhVien(String maSV, String hoTen, String soDT, String email) {
		super();
		this.maSV = maSV;
		this.tenSV = hoTen;
		this.soDT = soDT;
		this.email = email;
	}

	public String getMaSV() {
		return maSV;
	}

	public String getTenSV() {
		return tenSV;
	}

	public String getSoDT() {
		return soDT;
	}

	public String getEmail() {
		return email;
	}

	@Override
	public int compareTo(Object o) {
		SinhVien a = (SinhVien) o;
		return this.maSV.compareTo(a.getMaSV());
	}

	@Override
	public String toString() {
		return this.getMaSV() + " " + this.getTenSV() + " " + this.dt.getTenDeTai() + " " + this.dt.getTenGV();
	}

	public DeTai getDt() {
		return dt;
	}

	public void setDt(DeTai dt) {
		this.dt = dt;
	}

	public String getHd() {
		return hd;
	}

	public void setHd(String hd) {
		this.hd = hd;
	}
	
	

}
