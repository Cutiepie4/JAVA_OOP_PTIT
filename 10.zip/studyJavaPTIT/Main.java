package studyJavaPTIT;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.util.TreeSet;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {

		Scanner sc = new Scanner(new File("SINHVIEN.in"));

		int n = Integer.valueOf(sc.nextLine());

		ArrayList<SinhVien> listSV = new ArrayList<>();

		while (n-- > 0) {
			listSV.add(new SinhVien(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine()));
		}

		sc = new Scanner(new File("DETAI.in"));

		n = Integer.valueOf(sc.nextLine());

		ArrayList<DeTai> listDT = new ArrayList<>();

		while (n-- > 0) {
			listDT.add(new DeTai(sc.nextLine(), sc.nextLine()));
		}

		sc = new Scanner(new File("HOIDONG.in"));

		n = Integer.valueOf(sc.nextLine());

		TreeSet<String> listHD = new TreeSet<>();

		while (n-- > 0) {
			String maSV = sc.next(), maDT = sc.next(), tenHD = sc.next();
			outer: for (SinhVien i : listSV) {
				if (i.getMaSV().equals(maSV)) {
					for (DeTai j : listDT) {
						if (j.getMaDT().equals(maDT)) {
							i.setDt(j);
						}
					}
					i.setHd(tenHD);
					listHD.add(tenHD);
					break outer;
				}
			}
		}

		Collections.sort(listSV);

		for (String i : listHD) {
			System.out.println("DANH SACH HOI DONG " + i.charAt(i.length() - 1) + ":");
			for (SinhVien j : listSV) {
				if (i.equals(j.getHd())) {
					System.out.println(j);
				}
			}
		}
	}
}