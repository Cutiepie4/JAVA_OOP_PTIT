package oopPakage;

public class SinhVien {
	private String maSV, hoTen, lop, diemDanh;

	public SinhVien(String maSV, String hoTen, String lop) {
		super();
		this.maSV = maSV;
		this.hoTen = hoTen;
		this.lop = lop;
	}

	public String getMaSV() {
		return maSV;
	}

	public String getHoTen() {
		return hoTen;
	}

	public String getLop() {
		return lop;
	}

	public void parseString(String s) {
		int sum = 10;
		for (Character i : s.toCharArray()) {
			if (i == 'm')
				sum--;
			else if (i == 'v')
				sum -= 2;
		}

		if(sum <= 0) this.diemDanh = "0 KDDK";
		else this.diemDanh = String.valueOf(sum);
	}

	@Override
	public String toString() {
		return this.maSV + " " + this.hoTen + " " + this.lop + " " + this.diemDanh; 
	}
	
	
}
