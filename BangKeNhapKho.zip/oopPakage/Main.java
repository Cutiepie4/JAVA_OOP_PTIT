package oopPakage;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());

		while (n-- > 0) {
			System.out.println(
					new MatHang(sc.nextLine(), Integer.valueOf(sc.nextLine()), Integer.valueOf(sc.nextLine())));
		}
	}

}