package danhsachsinhvien1;

import java.util.ArrayList;

public class Group {
	private String name;
	private int id;
	private static int id_count = 1;
	public ArrayList<Student> listMember = new ArrayList<>();
	public static ArrayList<Group> listGroup = new ArrayList<Group>();

	public Group(String name) {
		super();
		this.name = name;
		this.id = id_count++;
		listGroup.add(this);
	}

	public static void getMembers() {
		for (Student i : Student.listStudent) {
			for (Group j : Group.listGroup) {
				if (j.id == i.getGroup()) {
					j.listMember.add(i);
					break;
				}
			}
		}
	}

	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		String message = String.format("DANH SACH NHOM %d:\n", this.id);
		for (Student i : this.listMember) {
			message += i.toString();
		}
		return message + String.format("Bai tap dang ky: %s", this.name);
	}

}
