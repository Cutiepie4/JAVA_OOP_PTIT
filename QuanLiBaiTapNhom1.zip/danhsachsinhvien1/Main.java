package danhsachsinhvien1;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void check(BigInteger bi, ArrayList<Integer> num) {
		String s = String.valueOf(bi);
		for (char i : s.toCharArray()) {
			num.remove(Integer.valueOf(String.valueOf(i)));
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt(), m = sc.nextInt();
		sc.nextLine();
		for (int i = 0; i < n; i++) {
			new Student(sc.nextLine(), sc.nextLine(), sc.nextLine(), Integer.valueOf(sc.nextLine()));
		}

		for (int i = 0; i < m; i++) {
			new Group(sc.nextLine());
		}
		
		Group.getMembers();
		int query = Integer.valueOf(sc.nextLine());
		while (query-- > 0) {
			int group = sc.nextInt();
			for (Group i : Group.listGroup) {
				if (i.getId() == group) {
					System.out.println(i);
				}
			}
		}
	}
}
