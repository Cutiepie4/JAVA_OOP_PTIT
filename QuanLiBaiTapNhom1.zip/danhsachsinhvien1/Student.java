package danhsachsinhvien1;

import java.util.ArrayList;

public class Student {
	public static ArrayList<Student> listStudent = new ArrayList<Student>();
	private String id, name, phoneNumber;
	private int group;
	public Student(String id, String name, String phoneNumber, int group) {
		super();
		this.id = id;
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.group = group;
		listStudent.add(this);
	}
	public int getGroup() {
		return group;
	}
	@Override
	public String toString() {
		return this.id + " " + this.name + " " + this.phoneNumber + "\n";
	}
	
	
	
}
