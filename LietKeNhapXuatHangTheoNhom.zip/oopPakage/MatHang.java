package oopPakage;

import java.util.ArrayList;
import java.util.HashMap;

public class MatHang implements Comparable<MatHang> {

	public static HashMap<String, ArrayList<MatHang>> data = new HashMap<>();
	private String id;
	private long num;

	public static void init() {
		data.put("A", new ArrayList<>());
		data.put("B", new ArrayList<>());
	}

	public MatHang(String id, long num) {
		super();
		this.id = id;
		this.num = num;
		MatHang.data.get(String.valueOf(this.id.charAt(0))).add(this);
	}

	public long getOutNum() {
		if (this.id.charAt(0) == 'A') {
			return Math.round(this.num * 6 / 10f);
		}
		return Math.round(this.num * 7 / 10f);
	}

	public long getUnit() {
		if (this.id.charAt(this.id.length() - 1) == 'Y') {
			return 110000;
		}
		return 135000;
	}

	public long getPrice() {
		return getOutNum() * getUnit();
	}

	public long getTax() {
		if (this.id.charAt(0) == 'A') {
			if (this.id.charAt(this.id.length() - 1) == 'Y') {
				return getPrice() * 8 / 100;
			}
			return getPrice() * 11 / 100;
		} else {
			if (this.id.charAt(this.id.length() - 1) == 'Y') {
				return getPrice() * 17 / 100;
			}
			return getPrice() * 22 / 100;
		}
	}

	@Override
	public String toString() {
		return this.id + " " + this.num + " " + this.getOutNum() + " " + getUnit() + " " + getPrice() + " " + getTax();
	}

	@Override
	public int compareTo(MatHang o) {
		if (this.getTax() > o.getTax())
			return -1;
		return 1;
	}

}
