package oopPakage;

import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());
		MatHang.init();
		while (n-- > 0) {
			new MatHang(sc.nextLine(), Long.valueOf(sc.nextLine()));
		}

		String query = sc.nextLine();
		Collections.sort(MatHang.data.get(query));
		
		for (MatHang i : MatHang.data.get(query)) {
			System.out.println(i);
		}
	}

}