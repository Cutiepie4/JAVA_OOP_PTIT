package qlibanhang1;

public class Bill {
	private static int idCount = 1;
	private String id;
	private Customer customer;
	private Product product;
	private int quantity;

	public Bill(String customerID, String productID, int quantity) {
		super();
		this.id = "HD" + String.format("%03d", Bill.idCount++);
		for (Customer i : Customer.listCustomer) {
			if (i.getId().equals(customerID)) {
				this.customer = i;
				break;
			}
		}

		for (Product i : Product.listProduct) {
			if (i.getId().equals(productID)) {
				this.product = i;
				break;
			}
		}
		this.quantity = quantity;
	}

	private long getTotalBill() {
		return this.product.getOutPrice() * this.quantity;
	}

	@Override
	public String toString() {
		return this.id + " " + this.customer.toString() + " " + this.product.toString() + " " + this.quantity + " "
				+ this.getTotalBill();
	}

}
