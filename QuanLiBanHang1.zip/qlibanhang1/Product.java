package qlibanhang1;

import java.util.ArrayList;

public class Product {
	public static ArrayList<Product> listProduct = new ArrayList<>();
	private static int idCount = 1;
	private String id, name, unit;
	private long inPrice, outPrice;

	public Product(String name, String unit, long inPrice, long outPrice) {
		super();
		this.id = "MH" + String.format("%03d", Product.idCount++);
		this.name = name;
		this.unit = unit;
		this.inPrice = inPrice;
		this.outPrice = outPrice;
		listProduct.add(this);
	}

	public String getId() {
		return id;
	}

	public long getOutPrice() {
		return outPrice;
	}

	@Override
	public String toString() {
		return this.name + " " + this.unit + " " + this.inPrice + " " + this.outPrice;
	}

}
