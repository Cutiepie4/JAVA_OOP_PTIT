package qlibanhang1;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());

		while (n-- > 0) {
			new Customer(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
		}

		n = Integer.valueOf(sc.nextLine());

		while (n-- > 0) {
			new Product(sc.nextLine(), sc.nextLine(), Long.valueOf(sc.nextLine()), Long.valueOf(sc.nextLine()));
		}

		n = Integer.valueOf(sc.nextLine());

		while (n-- > 0) {
			System.out.println(new Bill(sc.next(), sc.next(), Integer.valueOf(sc.next())));
		}
	}

}
