package danhsachsinhvien1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

public class Customer implements Comparable<Customer> {
	private static int id_order = 1;
	private String name, sex, address, id;
	private Date dob;

	private String formatName(String name) {
		StringTokenizer st = new StringTokenizer(name);
		String ans = "";
		while(st.hasMoreTokens()) {
			String i = st.nextToken().toLowerCase();
			ans += i.substring(0, 1).toUpperCase() + i.substring(1) + " ";
		}
		return ans;
	}

	public Customer(String name, String sex, String dob, String address) throws ParseException {
		super();
		this.id = String.format("KH%03d", Customer.id_order++);
		this.name = this.formatName(name);
		this.sex = sex;
		this.dob = new SimpleDateFormat("dd/MM/yyyy").parse(dob);
		this.address = address;
	}

	@Override
	public int compareTo(Customer o) {
		return this.dob.compareTo(o.dob);
	}

	@Override
	public String toString() {
		return this.id + " " + this.name + " " + this.sex + " " + this.address + " "
				+ new SimpleDateFormat("dd/MM/yyyy").format(dob);
	}

}
