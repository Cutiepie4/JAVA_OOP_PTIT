package danhsachsinhvien1;

import java.util.ArrayList;

public class Group {
	private String name;
	private int id;
	private static int id_count = 1;
	public ArrayList<Student> listMember = new ArrayList<>();
	public static ArrayList<Group> listGroup = new ArrayList<Group>();

	public Group(String name) {
		super();
		this.name = name;
		this.id = id_count++;
		listGroup.add(this);
	}

	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return this.id + " " + this.name;
	}

}
