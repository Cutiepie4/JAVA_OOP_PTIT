package danhsachsinhvien1;

import java.util.ArrayList;
import java.util.Collections;

public class Student implements Comparable<Student> {
	public static ArrayList<Student> listStudent = new ArrayList<Student>();
	private String id, name, phoneNumber;
	private int id_group;
	private Group group;

	public Student(String id, String name, String phoneNumber, int group) {
		super();
		this.id = id;
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.id_group = group;
		listStudent.add(this);
	}

	public static void getGroup() {
		for (Student i : listStudent) {
			for (Group j : Group.listGroup) {
				if (i.id_group == j.getId()) {
					i.group = j;
					break;
				}
			}
		}
		Collections.sort(listStudent);
	}

	@Override
	public String toString() {
		return this.id + " " + this.name + " " + this.phoneNumber + " " + this.group.toString();
	}

	@Override
	public int compareTo(Student o) {
		return this.id.compareTo(o.id);
	}

}
