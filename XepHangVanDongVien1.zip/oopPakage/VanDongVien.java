package oopPakage;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class VanDongVien implements Comparable<VanDongVien> {

	private String name, id;
	private LocalTime timeStart, timeEnd;
	private LocalDate dob;

	public VanDongVien(int id, String name, String dob, String timeStart, String timeEnd) {
		this.id = "VDV" + String.format("%02d", id);
		this.name = name;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		this.dob = LocalDate.parse(dob, dtf);
		dtf = DateTimeFormatter.ISO_LOCAL_TIME;
		this.timeStart = LocalTime.parse(timeStart, DateTimeFormatter.ofPattern("HH:mm:ss"));
		this.timeEnd = LocalTime.parse(timeEnd, DateTimeFormatter.ofPattern("HH:mm:ss"));
	}

	private LocalTime getExactTime() {
		return this.timeEnd.minusSeconds(this.timeStart.toSecondOfDay());
	}

	public LocalTime getFinalTime() {
		return this.timeEnd.minusSeconds(this.timeStart.toSecondOfDay() + getExtraSecond());
	}

	private String parseString(LocalTime lt) {
		return String.format("%02d:%02d:%02d", lt.getHour(), lt.getMinute(), lt.getSecond());
	}

	private int getExtraSecond() {
		int x = 2021 - this.dob.getYear();
		if (x < 18)
			return 0;
		else if (x < 25)
			return 1;
		else if (x < 32)
			return 2;
		return 3;
	}

	private String getExtraTime() {
		return String.format("00:00:%02d", getExtraSecond());
	}

	@Override
	public int compareTo(VanDongVien o) {
		if (this.getFinalTime().compareTo(o.getFinalTime()) < 0) {
			return -1;
		}
		return 1;
		
	}

	@Override
	public String toString() {
		return this.id + " " + this.name + " " + this.parseString(this.getExactTime()) + " " + this.getExtraTime() + " "
				+ this.parseString(this.getFinalTime());
	}

}