package oopPakage;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());

		ArrayList<MatHang> data = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			data.add(new MatHang(sc.nextLine(), sc.nextLine(), sc.nextLine()));
		}

		int m = Integer.valueOf(sc.nextLine());
		while (m-- > 0) {
			String ma = sc.next();
			for (MatHang i : data) {
				if (i.getMa().equals(ma)) {
					i.parse(Integer.valueOf(sc.next()), Integer.valueOf(sc.next()), Integer.valueOf(sc.next()));
					System.out.println(i);
					break;
				}
			}
		}
	}
}
