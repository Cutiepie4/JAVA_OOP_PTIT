package oopPakage;

public class MatHang {
	private String ma, ten;
	private int lai, inPrice, outPrice;
	public MatHang(String ma, String ten, String lai) {
		super();
		this.ma = ma;
		this.ten = ten;
		switch(lai) {
		case "A":
			this.lai = 8;
			break;
		case "B":
			this.lai = 5;
			break;
		case "C":
			this.lai = 2;
			break;
		}
	}
	
	public void parse(int in, int inUnitPrice, int out) {
		this.inPrice = in * inUnitPrice;
		this.outPrice = inUnitPrice * out * (100 + this.lai) / 100;
	}

	public int getInPrice() {
		return inPrice;
	}

	public int getOutPrice() {
		return outPrice;
	}
	
	

	public String getMa() {
		return ma;
	}

	@Override
	public String toString() {
		return this.ma + " " + this.ten + " " + this.inPrice + " " + this.outPrice;
	}
	
	
}
