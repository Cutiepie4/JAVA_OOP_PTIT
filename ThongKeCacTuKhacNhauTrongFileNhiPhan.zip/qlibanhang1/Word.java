package qlibanhang1;

public class Word implements Comparable<Word> {
	private String word;
	private int count;

	public Word(String word, int count) {
		super();
		this.word = word;
		this.count = count;
	}

	@Override
	public int compareTo(Word o) {
		if (this.count > o.count)
			return -1;
		if (this.count == o.count)
			return this.word.compareTo(o.word);
		return 1;
	}

	@Override
	public String toString() {
		return this.word + " " + this.count;
	}

}
