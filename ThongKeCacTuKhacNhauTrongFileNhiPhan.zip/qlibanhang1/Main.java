package qlibanhang1;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class Main {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		ObjectInputStream input = new ObjectInputStream(new FileInputStream(new File("DATA.in")));
		ArrayList<String> listText = (ArrayList<String>) input.readObject();

		HashMap<String, Integer> data = new HashMap<>();

		String text = "";

		for (String i : listText) {
			text += i + " ";
		}

		String temp = "";
		for (Character i : text.toCharArray()) {
			if (Character.isLetterOrDigit(i))
				temp += Character.toLowerCase(i);
			else {
				if (!temp.isEmpty()) {
					if (!data.containsKey(temp)) {
						data.put(temp, 0);
					}
					data.put(temp, data.get(temp) + 1);
				}
				temp = "";
			}
		}

		ArrayList<Word> listWord = new ArrayList<>();

		for (String i : data.keySet()) {
			listWord.add(new Word(i, data.get(i)));
		}

		Collections.sort(listWord);

		for (Word i : listWord) {
			System.out.println(i);
		}
	}

}
