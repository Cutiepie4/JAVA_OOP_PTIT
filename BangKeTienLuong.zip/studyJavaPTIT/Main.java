package studyJavaPTIT;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int n = Integer.valueOf(sc.nextLine());
		long tongTienLuong = 0;
		for (int i = 0; i < n; i++) {
			NhanVien a = new NhanVien(i + 1, sc.nextLine(), Integer.valueOf(sc.nextLine()),
					Integer.valueOf(sc.nextLine()), sc.nextLine());
			System.out.println(a);
			tongTienLuong += a.getThucLinh();
		}
		System.out.println("Tong chi phi tien luong: " + tongTienLuong);
	}
}
