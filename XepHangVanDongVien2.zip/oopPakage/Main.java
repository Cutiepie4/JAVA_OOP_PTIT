package oopPakage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());

		ArrayList<VanDongVien> data = new ArrayList<VanDongVien>();

		for (int i = 0; i < n; i++) {
			data.add(new VanDongVien(i + 1, sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine()));
		}

		Collections.sort(data);

		HashMap<VanDongVien, Integer> rank = new HashMap<>();

		rank.put(data.get(0), 1);

		for (int i = 1; i < data.size(); i++) {
			if (!data.get(i - 1).getFinalTime().equals(data.get(i).getFinalTime())) {
				rank.put(data.get(i), i + 1);
			} else {
				rank.put(data.get(i), rank.get(data.get(i - 1)));
			}
		}

		for (VanDongVien i : data) {
			System.out.println(i + " " + rank.get(i));
		}
		
	}
}
