package oopPakage;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());
		ArrayList<KhachHang> data = new ArrayList<KhachHang>();
		while (n-- > 0) {
			data.add(new KhachHang(sc.nextLine(), Long.valueOf(sc.nextLine()), Long.valueOf(sc.nextLine())));
		}
		Collections.sort(data);
		for (KhachHang i : data) {
			System.out.println(i);
		}
	}

}