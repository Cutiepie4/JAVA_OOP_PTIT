package oopPakage;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());

		ArrayList<MatHang> data = new ArrayList<MatHang>();

		while (n-- > 0) {
			data.add(new MatHang(sc.nextLine(), Integer.valueOf(sc.nextLine()), Integer.valueOf(sc.nextLine())));
		}

		Collections.sort(data);
		for (MatHang i : data) {
			System.out.println(i);
		}
	}

}