package oopPakage;

import java.util.HashMap;
import java.util.StringTokenizer;

public class MatHang implements Comparable<MatHang> {
	private static HashMap<String, Integer> allID = new HashMap<>();
	private String id, name;
	private int num, unitPrice;

	public MatHang(String name, int num, int unitPrice) {
		super();
		this.name = name;
		this.num = num;
		this.unitPrice = unitPrice;
		parseID(name);
	}

	private void parseID(String name) {
		StringTokenizer st = new StringTokenizer(name);
		int t = 2;
		String id = "";
		while (t-- > 0 && st.hasMoreTokens()) {
			id += st.nextToken().substring(0, 1).toUpperCase();
		}
		if (!MatHang.allID.containsKey(id)) {
			MatHang.allID.put(id, 0);
		}
		MatHang.allID.put(id, MatHang.allID.get(id) + 1);
		this.id = id + String.format("%02d", MatHang.allID.get(id));
	}

	public int getDiscountPrice() {
		int discountPercent = 0;
		if (num < 5) {
			discountPercent = 0;
		} else if (num < 8) {
			discountPercent = 1;
		} else if (num < 11) {
			discountPercent = 2;
		} else
			discountPercent = 5;

		return this.num * this.unitPrice * discountPercent / 100;
	}

	public int getTotalPrice() {
		return this.num * this.unitPrice - this.getDiscountPrice();
	}

	@Override
	public String toString() {
		return this.id + " " + this.name + " " + this.getDiscountPrice() + " " + this.getTotalPrice();
	}

	@Override
	public int compareTo(MatHang o) {
		if (this.getDiscountPrice() > o.getDiscountPrice())
			return -1;
		return 1;
	}

}
