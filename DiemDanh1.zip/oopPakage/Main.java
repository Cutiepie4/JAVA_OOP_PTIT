package oopPakage;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());

		ArrayList<SinhVien> data = new ArrayList<>();

		for (int i = 0; i < n; i++) {
			data.add(new SinhVien(sc.nextLine(), sc.nextLine(), sc.nextLine()));
		}

		for (int i = 0; i < n; i++) {
			String s = sc.next();
			for (SinhVien j : data) {
				if (j.getMaSV().equals(s)) {
					j.parseString(sc.next());
					break;
				}
			}
		}

		for (SinhVien i : data) {
			System.out.println(i);
		}
	}
}
