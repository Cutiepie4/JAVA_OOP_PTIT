package oopPakage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());

		ArrayList<Club> data = new ArrayList<>();

		while (n-- > 0) {
			data.add(new Club(sc.nextLine(), sc.nextLine(), Integer.valueOf(sc.nextLine())));
		}

		ArrayList<Match> data1 = new ArrayList<>();
		int Q = Integer.valueOf(sc.nextLine());
		while (Q-- > 0) {
			String id = sc.next();
			int seat = sc.nextInt();

			for (Club i : data) {
				if (i.getId().equals(id.substring(1, 3))) {
					data1.add(new Match(id, i, seat));
				}
			}
		}

		Collections.sort(data1);

		for (Match i : data1) {
			System.out.println(i);
		}
	}
}
