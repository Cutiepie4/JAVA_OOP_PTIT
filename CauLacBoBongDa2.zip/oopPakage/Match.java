package oopPakage;

public class Match implements Comparable<Match> {
	private String id;
	private Club club;
	private int earning;

	public Match(String id, Club club, int seat) {
		super();
		this.id = id;
		this.club = club;
		this.earning = this.club.getTicket() * seat;
	}

	public String getId() {
		return id;
	}

	public Club getClub() {
		return club;
	}

	public int getEarning() {
		return earning;
	}

	@Override
	public int compareTo(Match o) {
		if (this.getEarning() > o.getEarning())
			return -1;
		if (this.getEarning() == o.getEarning())
			return this.club.getName().compareTo(o.getClub().getName());
		return 1;
	}

	@Override
	public String toString() {
		return this.id + " " + this.club.getName() + " " + this.earning;
	}
	
	

}
