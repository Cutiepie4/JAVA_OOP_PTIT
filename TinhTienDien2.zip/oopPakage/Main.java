package oopPakage;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());
		while (n-- > 0) {
			System.out.println(
					new KhachHang(sc.nextLine(), Long.valueOf(sc.nextLine()), Long.valueOf(sc.nextLine())));
		}

	}

}