package oopPakage;

public class KhachHang {
	private String SDtype, id;
	private long num;
	private static int count = 1;

	public KhachHang(String sDtype, long last, long curr) {
		super();
		this.id = "KH" + String.format("%02d", KhachHang.count++);
		this.SDtype = sDtype;
		this.num = curr - last;
	}

	public long getBase() {
		switch (SDtype) {
		case "KD":
			return 3;
		case "NN":
			return 5;
		case "TT":
			return 4;
		case "CN":
			return 2;
		}
		return 0;
	}

	public long getPrice() {
		return this.num * getBase() * 550;
	}

	public long getBonus() {
		if (this.num < 50) {
			return 0;
		} else if (this.num < 101) {
			return Math.round(getPrice() * 35 / 100f);
		}
		return getPrice();
	}

	public long getTotalPrice() {
		return getPrice() + getBonus();
	}

	@Override
	public String toString() {
		return this.id + " " + getBase() + " " + getPrice() + " " + getBonus() + " " + getTotalPrice();
	}

}
