package qlibanhang1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main {
	public static void main(String[] args) throws FileNotFoundException {
		Scanner sc = new Scanner(new File("VANBAN.in"));

		HashMap<String, Integer> data = new HashMap<>();

		int n = Integer.valueOf(sc.nextLine());
		String text = "";

		while (n-- > 0) {
			text += sc.nextLine() + " ";
		}

		String temp = "";
		for (Character i : text.toCharArray()) {
			if (Character.isLetterOrDigit(i))
				temp += Character.toLowerCase(i);
			else {
				if (!temp.isEmpty()) {
					if (!data.containsKey(temp)) {
						data.put(temp, 0);
					}
					data.put(temp, data.get(temp) + 1);
				}
				temp = "";
			}
		}

		ArrayList<Word> listWord = new ArrayList<>();

		for (String i : data.keySet()) {
			listWord.add(new Word(i, data.get(i)));
		}

		Collections.sort(listWord);

		for (Word i : listWord) {
			System.out.println(i);
		}
	}

}
