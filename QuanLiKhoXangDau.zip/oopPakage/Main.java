package oopPakage;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();

		new MatHang("X", 128000, 6);
		new MatHang("D", 11200, 7);
		new MatHang("N", 9700, 4);

		new NguonGoc("BP", "British Petro");
		new NguonGoc("ES", "Esso");
		new NguonGoc("SH", "Shell");
		new NguonGoc("CA", "Castrol");
		new NguonGoc("MO", "Mobil");
		new NguonGoc("TN", "Trong Nuoc");

		while (n-- > 0) {
			System.out.println(new DonHang(sc.next(), sc.nextLong()));
		}

	}
}
