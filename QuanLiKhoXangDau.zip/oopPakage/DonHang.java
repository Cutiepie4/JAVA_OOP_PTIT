package oopPakage;

public class DonHang {
	private MatHang mh;
	private NguonGoc ng;
	private String id;
	private long soLuong;

	public DonHang(String id, long soLuong) {
		super();
		this.id = id;
		this.soLuong = soLuong;
		for (MatHang i : MatHang.data) {
			if (i.getMa().equals(this.id.substring(0, 1))) {
				this.mh = i;
				break;
			}
		}
		for (NguonGoc i : NguonGoc.data) {
			if (this.id.endsWith(i.getMa())) {
				this.ng = i;
				break;
			}
		}
	}

	public long getThue() {
		if (this.ng.getMa().equals("TN"))
			return 0;
		return (long) (this.soLuong * this.mh.getDonGia() * this.mh.getThue() / 200);
	}

	public long getTong() {
		return this.soLuong * this.mh.getDonGia() + this.getThue();
	}

	@Override
	public String toString() {
		return this.id + " " + this.ng.getTen() + " " + this.mh.getDonGia() + " " + this.getThue() + " "
				+ this.getTong();
	}

}
