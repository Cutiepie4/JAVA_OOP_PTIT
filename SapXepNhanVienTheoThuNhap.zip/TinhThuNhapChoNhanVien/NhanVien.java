package TinhThuNhapChoNhanVien;

public class NhanVien implements Comparable{
	
	private String hoTen, chucVu, maNV;
	private int luongCoBan, ngayCong;

	public NhanVien(int id, String hoTen, String chucVu, int luongCoBan, int ngayCong) {
		super();
		this.maNV = "NV" + String.format("%02d", id);
		this.hoTen = hoTen;
		this.chucVu = chucVu;
		this.luongCoBan = luongCoBan;
		this.ngayCong = ngayCong;
 	}

	public int getPhuCapChucVu() {
		switch (chucVu) {
		case "GD":
			return 500;

		case "PGD":
			return 400;

		case "TP":
			return 300;

		case "KT":
			return 250;
		}
		return 100;
	}

	public int getLuong() {
		return this.luongCoBan * this.ngayCong;
	}

	public int getTamUng() {
		float temp = (this.getPhuCapChucVu() + this.getLuong()) * 2 / 3;
		if (temp < 25000) {
			return (int) (Math.round((float) temp / 1000) * 1000);
		}
		return 25000;
	}

	@Override
	public String toString() {
		return String.format("%s %s %d %d %d %d", this.maNV, this.hoTen, this.getPhuCapChucVu(), this.getLuong(),
				this.getTamUng(), this.getLuong() + this.getPhuCapChucVu() - this.getTamUng());
	}

	@Override
	public int compareTo(Object o) {
		NhanVien a = (NhanVien) o;
		if(this.getLuong() + this.getPhuCapChucVu() > a.getLuong() + a.getPhuCapChucVu()) return -1;
		return 1;
	}

}
