package oopPakage;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());

		ArrayList<Club> data = new ArrayList<>();

		while (n-- > 0) {
			data.add(new Club(sc.nextLine(), sc.nextLine(), Integer.valueOf(sc.nextLine())));
		}

		int Q = Integer.valueOf(sc.nextLine());
		while (Q-- > 0) {
			String id = sc.next();
			int seat = sc.nextInt();

			for (Club i : data) {
				if (i.getId().equals(id.substring(1, 3))) {
					System.out.println(id + " " + i.getName() + " " + seat * i.getTicket());
				}
			}
		}

	}
}
