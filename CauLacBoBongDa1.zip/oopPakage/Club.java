package oopPakage;

public class Club {
	private String id, name;
	private int ticket;

	public Club(String id, String name, int seat) {
		super();
		this.id = id;
		this.name = name;
		this.ticket = seat;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public int getTicket() {
		return ticket;
	}

	
}
