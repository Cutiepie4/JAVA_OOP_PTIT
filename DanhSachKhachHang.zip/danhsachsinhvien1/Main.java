package danhsachsinhvien1;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws ParseException {
		Scanner sc = new Scanner(System.in);
		int n = Integer.valueOf(sc.nextLine());

		ArrayList<Customer> data = new ArrayList<Customer>();

		while (n-- > 0) {
			data.add(new Customer(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine()));
		}

		Collections.sort(data);
		for (Customer i : data) {
			System.out.println(i);
		}
	}
}
