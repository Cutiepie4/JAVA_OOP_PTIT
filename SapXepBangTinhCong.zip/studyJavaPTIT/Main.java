package studyJavaPTIT;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int n = Integer.valueOf(sc.nextLine());
		ArrayList<NhanVien> data = new ArrayList<>();
		for (int i = 0; i < n; i++) {
			NhanVien a = new NhanVien(i + 1, sc.nextLine(), Integer.valueOf(sc.nextLine()),
					Integer.valueOf(sc.nextLine()), sc.nextLine());
			data.add(a);
		}

		Collections.sort(data);
		for (NhanVien i : data) {
			System.out.println(i);
		}
	}
}
