package studyJavaPTIT;

public class NhanVien implements Comparable {
	private String maNV, hoTen, chucVu;
	private int luongNgay, ngayCong;

	public NhanVien(int id, String hoTen, int luongNgay, int ngayCong, String chucVu) {
		super();
		if (id < 10)
			this.maNV = "NV0" + id;
		else
			this.maNV = "NV" + id;
		this.hoTen = hoTen;
		this.chucVu = chucVu;
		this.luongNgay = luongNgay;
		this.ngayCong = ngayCong;
	}

	public int getLuongThang() {
		return this.ngayCong * this.luongNgay;
	}

	public int getPhuCapChucVu() {
		if (this.chucVu.equals("GD"))
			return 250000;
		else if (this.chucVu.equals("PGD"))
			return 200000;
		else if (this.chucVu.equals("TP"))
			return 180000;
		return 150000;
	}

	public int getThuong() {
		if (this.ngayCong >= 25)
			return this.getLuongThang() / 5;
		else if (this.ngayCong >= 22)
			return this.getLuongThang() / 10;

		return 0;
	}

	public int getThucLinh() {
		return this.getLuongThang() + this.getPhuCapChucVu() + this.getThuong();
	}

	@Override
	public String toString() {
		return maNV + " " + hoTen + " " + getLuongThang() + " " + getThuong() + " " + getPhuCapChucVu() + " "
				+ getThucLinh();
	}

	@Override
	public int compareTo(Object o) {
		NhanVien a = (NhanVien) o;
		if (this.getThucLinh() > a.getThucLinh())
			return -1;
		return 1;
	}

}
