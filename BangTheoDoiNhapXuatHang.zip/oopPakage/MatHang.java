package oopPakage;

public class MatHang {
	private String id;
	private long num;

	public MatHang(String id, long num) {
		super();
		this.id = id;
		this.num = num;
	}

	public long getOutNum() {
		if (this.id.charAt(0) == 'A') {
			return Math.round(this.num * 6 / 10f);
		}
		return Math.round(this.num * 7 / 10f);
	}

	public long getUnit() {
		if (this.id.charAt(this.id.length() - 1) == 'Y') {
			return 110000;
		}
		return 135000;
	}

	public long getPrice() {
		return getOutNum() * getUnit();
	}

	public long getTax() {
		if (this.id.charAt(0) == 'A') {
			if (this.id.charAt(this.id.length() - 1) == 'Y') {
				return getPrice() * 8 / 100;
			}
			return getPrice() * 11 / 100;
		} else {
			if (this.id.charAt(this.id.length() - 1) == 'Y') {
				return getPrice() * 17 / 100;
			}
			return getPrice() * 22 / 100;
		}
	}

	@Override
	public String toString() {
		return this.id + " " + this.num + " " + this.getOutNum() + " " + getUnit() + " " + getPrice() + " " + getTax();
	}

}
