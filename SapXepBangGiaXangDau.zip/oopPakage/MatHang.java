package oopPakage;

import java.util.ArrayList;

public class MatHang {
	public static ArrayList<MatHang> data = new ArrayList<>();
	private String ma;
	private long donGia;
	private int thue;

	public MatHang(String ma, int donGia, int thue) {
		super();
		this.ma = ma;
		this.donGia = donGia;
		this.thue = thue;
		data.add(this);
	}

	public String getMa() {
		return ma;
	}

	public long getDonGia() {
		return donGia;
	}

	public int getThue() {
		return thue;
	}

}