package oopPakage;

import java.util.ArrayList;

public class NguonGoc {
	public static ArrayList<NguonGoc> data = new ArrayList<>();
	private String ma, ten;

	public NguonGoc(String ma, String ten) {
		super();
		this.ma = ma;
		this.ten = ten;
		data.add(this);
	}

	public String getMa() {
		return ma;
	}

	public String getTen() {
		return ten;
	}

}
