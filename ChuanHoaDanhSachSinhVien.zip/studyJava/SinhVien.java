package studyJava;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

public class SinhVien {
	private String maSV, hoTen, lop;
	private float gpa;
	private Date ngaySinh;

	public SinhVien(int maSV, String hoTen, String lop, String ngaySinh, float gpa) throws ParseException {
		super();
		if (maSV < 10) {
			this.maSV = "B20DCCN00" + maSV;
		} else
			this.maSV = "B20DCCN0" + maSV;
		this.hoTen = hoTen;
		this.lop = lop;
		this.gpa = gpa;
		this.ngaySinh = new SimpleDateFormat("dd/MM/yyyy").parse(ngaySinh);
		this.formatName();
	}

	private void formatName() {
		StringTokenizer st = new StringTokenizer(hoTen);

		this.hoTen = "";

		while (st.hasMoreTokens()) {
			String s = st.nextToken().toLowerCase();
			this.hoTen += s.substring(0, 1).toUpperCase() + s.substring(1) + " ";
		}
		this.hoTen.trim();
	}

	@Override
	public String toString() {
		return maSV + " " + hoTen + " " + lop + " " + new SimpleDateFormat("dd/MM/yyyy").format(ngaySinh) + " "
				+ String.format("%.2f", gpa);
	}

}
