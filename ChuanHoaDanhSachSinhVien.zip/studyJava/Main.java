package studyJava;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws FileNotFoundException, NumberFormatException, ParseException {

		Scanner sc = new Scanner(new File("SINHVIEN.in"));

		int n = Integer.valueOf(sc.nextLine());

		ArrayList<SinhVien> data = new ArrayList<>();

		for (int i = 0; i < n; i++) {
			data.add(new SinhVien(i + 1, sc.nextLine(), sc.nextLine(), sc.nextLine(), Float.valueOf(sc.nextLine())));
		}

		for (SinhVien i : data) {
			System.out.println(i);
		}
	}
}
